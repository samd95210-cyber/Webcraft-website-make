import { ArrowRight, CheckCircle } from 'lucide-react';

interface HeroProps {
  setCurrentPage: (page: string) => void;
}

export default function Hero({ setCurrentPage }: HeroProps) {
  return (
    <section className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8 pt-20 pb-20 relative overflow-hidden">
      {/* Background gradient effects */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-20 left-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl opacity-20"></div>
        <div className="absolute bottom-40 right-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl opacity-20"></div>
      </div>

      <div className="max-w-4xl mx-auto text-center">
        {/* Trust badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/30 mb-8">
          <CheckCircle size={16} className="text-blue-400" />
          <span className="text-sm text-blue-300 font-medium">Trusted by 50+ businesses in India</span>
        </div>

        {/* Main headline */}
        <h1 className="text-5xl sm:text-6xl md:text-7xl font-bold mb-6 leading-tight tracking-tight">
          <span className="block text-white">Modern Websites That</span>
          <span className="block bg-gradient-to-r from-blue-400 via-cyan-400 to-blue-300 bg-clip-text text-transparent">
            Grow Your Business
          </span>
        </h1>

        {/* Subheadline */}
        <p className="text-lg sm:text-xl text-slate-400 mb-8 max-w-2xl mx-auto leading-relaxed font-light">
          I build fast, mobile-friendly, SEO-ready websites for small businesses, shops, agencies, and creators. Get your professional website live in days, not months.
        </p>

        {/* Trust line */}
        <div className="flex flex-wrap justify-center gap-4 text-sm text-slate-500 mb-12">
          <span className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full"></span>
            Landing Pages
          </span>
          <span className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full"></span>
            Business Websites
          </span>
          <span className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full"></span>
            Portfolio Sites
          </span>
          <span className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full"></span>
            E-Commerce
          </span>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row justify-center gap-4 sm:gap-6">
          <button
            onClick={() => setCurrentPage('contact')}
            className="px-8 py-4 bg-gradient-to-r from-blue-500 to-cyan-400 text-slate-950 rounded-lg font-bold text-lg hover:from-blue-600 hover:to-cyan-500 transition-all transform hover:scale-105 flex items-center justify-center gap-2 shadow-lg shadow-blue-500/30"
          >
            Get Free Quote
            <ArrowRight size={20} />
          </button>
          <button
            onClick={() => setCurrentPage('portfolio')}
            className="px-8 py-4 border border-blue-500/50 text-blue-300 rounded-lg font-bold text-lg hover:bg-blue-500/10 transition-colors flex items-center justify-center gap-2"
          >
            View Portfolio
            <ArrowRight size={20} />
          </button>
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 sm:grid-cols-4 gap-6 text-center">
          <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50">
            <div className="text-3xl font-bold text-cyan-400">50+</div>
            <div className="text-sm text-slate-400">Projects Done</div>
          </div>
          <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50">
            <div className="text-3xl font-bold text-cyan-400">5 Days</div>
            <div className="text-sm text-slate-400">Avg Delivery</div>
          </div>
          <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50">
            <div className="text-3xl font-bold text-cyan-400">99%</div>
            <div className="text-sm text-slate-400">Satisfaction</div>
          </div>
          <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50">
            <div className="text-3xl font-bold text-cyan-400">24/7</div>
            <div className="text-sm text-slate-400">Support</div>
          </div>
        </div>
      </div>
    </section>
  );
}
